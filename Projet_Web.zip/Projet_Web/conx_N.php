<?php
//démarrer une session et établit une connexion à la base de données
session_start();
$bdd = new PDO("mysql:host=localhost;port=3308;dbname=dataproject", "root", "");
// vérifie ensuite si l'utilisateur a soumis un formulaire en cliquant sur le bouton "Valider"
if (isset($_POST['Valider'])) {
    //vérifie si le champ "Login" est rempli et récupère le mot de passe saisi
    if (!empty($_POST['Username'])) {
        $Password = htmlspecialchars($_POST['Username']);
        $recupUser = $bdd->prepare('SELECT * FROM influencer WHERE Username = ?');
        $recupUser->execute(array($Password));
         // exécute une requête préparée pour vérifier si un enregistrement avec le nom d'utilisateur correspondant existe dans la table "influencer"
         if ($recupUser->rowCount() > 0) {
            // la session de l'utilisateur est créée et il est redirigé vers autre page 
            $_SESSION['Username'] = $Password;
            $_SESSION['id_inf'] = $recupUser->fetch()['id_inf'];
            header('Location: index_N.php');
        } else {// un message d'erreur est affiché
            echo "Aucun utilisateur trouvé";
        }
        
    } else { //Si le champ "Login" est vide, un autre message d'erreur est affiché demandant à l'utilisateur de remplir le champ
        echo "Veuillez entrer votre pseudo";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
     <!--définit l'encodage des caractères utilisé pour afficher la page, qui est UTF-8-->
        <meta charset="UTF-8">
        <!--la page doit être rendue dans la dernière version compatible d'Internet Explorer-->
       <meta http-equiv="X-UA-Compatible" content="IE=edge">
       <!--les propriétés de l'affichage initial de la page sur les différents types d'appareils-->
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <!--d'ajouter des icônes à la page-->
       <script src="https://kit.fontawesome.com/687f59c35b.js" crossorigin="anonymous"></script>
       <link rel="stylesheet" href="message_inf.css">
        <title>Message</title>
        <!--  l'élément <link> qui définit l'icône de page-->
        <link rel="icon" href="images/l.gif" sizes="128x128" style="border-radius: 50%;">
</head>

<body>


    <div class="side-menu">
        <div class="lg">
      <a href="accueil.html"  > <img class="logo"src="images/logo.png"   alt="" > </li> </a>
          
        </div>
    </br>
         <ul><!--une liste de liens de navigation.-->
            <a href="espace_inf.php"><li><i class="fa-solid fa-house" style="color: #ffffff;"></i><span class="titre ">Home</span></li></a>
            <a href="espace_inf.php"><li><i class="fa-solid fa-user" style="color: #ffffff;"></i><span class="titre ">My Profile</span></li></a>
            <a  href="out.php"><li><i class="fa-solid fa-key" style="color: #ffffff;"></i><span class="titre ">Log out</span></li></a>
         </ul>
    </div>
   <br/><br/>

           <p style="color:#84abc2;">Sending a message for a brand is not just about promoting a product, it's about sharing a message that you truly believe in and inspiring others to take action</p>

   <br/>
        
 
    <div class="profile">
        <!--Lorsque l'utilisateur remplit le champ et clique sur le bouton "Valider", les données sont soumises au script PHP associé pour vérification et traitement de la demande de connexion -->   
      <h2 >Send a Message</h2>   
      <form method="POST" action="" >
        <label for="Username">Username:</label>
	    <input type="Username" id="Username" name="Username" placeholder="Enter your Username "><br>
	    <input type="submit" name="Valider">
       </form>
   
  
   </div>
  

</body>
</html>
